#ifndef COMUM_H
#define COMUM_H

#define MAIOR 2
#define MENOR 1
#define IGUAL 0

#endif
